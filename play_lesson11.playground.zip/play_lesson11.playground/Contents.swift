/*
 1. Написать функцию, которая ничего не возвращает и принимает только один клоужер, который ничего не принимает и ничего не возвращает . Функция должна просто посчитать от 1 до 10 в цикле и после этого вызвать клоужер. Добавьте println в каждый виток цикла и в клоужер и проследите за очередностью выполнения команд.
*/

//
//func countToTen(closure:() -> ()) {
//    for i in 1...10 {
//        print(i)
//    }
//    closure()
//}
//
//countToTen {
//    print("in closure")
//}

/*
2. Используя метод массивов sorted, отсортируйте массив интов по возрастанию и убыванию. Пример показан в методичке.
*/
//var arr = [1, 2, 4, 5, 2, 9, 22, 0, 43, 23, 3]

//print(arr.sorted(by: {($0 < $1)}))
//print(arr.sorted(by: {($0 > $1)}))

/*
3. Напишите функцию, которая принимает массив интов и клоужер и возвращает инт.
 Клоужер должен принимать 2 инта (один опшинал) и возвращать да или нет.
 В самой функции создайте опшинал переменную.
 Вы должны пройтись в цикле по массиву интов и сравнивать элементы с переменной используя клоужер.
 Если клоужер возвращает да, то вы записываете значение массива в переменную. в конце функции возвращайте переменную.
 Используя этот метод и этот клоужер найдите максимальный и минимальный элементы массива.
*/

/*
//let arr = [1, 2, 4, 5, 2, 9, 22, 0, -345, 345, 43, 23, 3]
let arr = [Int]()
func findInArr(arr: [Int], f: (Int, Int?) -> Bool) -> Int? {
    var result: Int?
    for i in arr {
        if result == nil || f(i, result) {
            result = i
        }
    }
    return result
}

let filtered = findInArr(arr: arr, f: {($0 > $1!)})

print(filtered as Any)
*/

/*
 4. Создайте произвольную строку. Преобразуйте ее в массив букв. Используя метод массивов sorted отсортируйте строку так, чтобы вначале шли гласные в алфавитном порядке, потом согласные, потом цифры, а потом символы
 */

//func sort(arr: [Character]) -> [Character] {
//    var sorted = ["volves":"", "consonant":"", "numbers":"", "symbols":""]
//
//    for c in arr {
//
//        let i = String(c).lowercased()
//
//        switch i.lowercased() {
//        case "a", "e", "i", "o", "u":
//            sorted["volves"] = sorted["volves"]! + i
//        case "a"..."z":
//            sorted["consonant"] = sorted["consonant"]! + i
//        case "0"..."9":
//            sorted["numbers"] = sorted["numbers"]! + i
//        default:
//            sorted["symbols"] = sorted["symbols"]! + i
//        }
//    }
//
//    for (name, value) in sorted {
//        // this wrong ----- sorted[name] = value.sorted(by: {($0 > $1)}
//        sorted[name] = String(value.sorted(by: {($0 > $1)}))
//    }
//    return Array(sorted["volves"]! + sorted["consonant"]! + sorted["numbers"]! + sorted["symbols"]!)
//}
//

func priority(_ string: String) -> Int {
    var priority = 0
    for i in string {
        let c = String(i).lowercased()
        switch c {
        case "a", "e", "i", "o", "u": priority = 1
        case "a"..."z": priority = 2
        case "0"..."9": priority =  3
        default: priority =  4
        }
    }
    return priority
}
    

let text = "LOojSdQ24Jslqgldfa*A9"
var textArr = [String]()
for c in text {
    textArr.append(String(c))
}

let sorted = textArr.sorted {(a,b) -> Bool in
    switch (priority(a), priority(b)){
    case let (a, b) where a < b: return true
    case let (a, b) where a > b: return false
    default: return a < b
    }
}

print(textArr)
print(sorted)

 /*
 5. Проделайте задание №3 но для нахождения минимальной и максимальной буквы из массива букв (соответственно скалярному значению)
 */

//
//let text = Array("LOojSdQJsZqgldfza".lowercased())
//
//func findInArr(arr: [Character], f: (Character, Character?) -> Bool) -> Character {
//    var result: Character?
//    for i in arr {
//        if result == nil || f(i, result) {
//            result = i
//        }
//    }
//    return result!
//}
//
//let filteredText = findInArr(arr: text, f: {$0 < $1!})
//print(filteredText)
//
//let filteredText2 = findInArr(arr: text, f: {$0 > $1!})
//print(filteredText2)


