//1. Создайте тип Комната. У комнаты есть размеры W на H. И создайте тип Персонаж. У негоесть координата в комнате X и Y. Реализуйте функцию, которая красивенько текстом будет показывать положение персонажа в комнате
//


// суббота 21:30 начало

class Room {
    
    static let minValue = 5
    static let maxValue = 255
    var hero : Hero?
    var boxes = [Box]()
    var targets = [Target]()
    
    var with : UInt8 {
        
        didSet {
            with = with < Room.minValue && with > Room.maxValue ? oldValue : with
        }
    }
    
    var heigth : UInt8 {
        
        didSet {
            heigth = heigth < Room.minValue && heigth > Room.maxValue ? oldValue : heigth
        }
    }
    
    func printRoom () {
        
        if let _ = hero {
            for y in (0 ... self.with - 1).reversed() {
                var row = ""
                
                for x in 0 ... self.heigth - 1 {
                    row += getCell(atX: x, andY: y)
                }
                print(row)
            }
        } else {
            print("ERROR: Hero not found at room, at first you need to add hero by: room.addHero(hero: man) command")
        }
    }
    
    func getCell(atX x: UInt8, andY y: UInt8) -> String {
        
        if !checkBounds(atX: x, andY: y) {
            return "⬛️"
        } else if isHero(atX: x, andY: y) {
            return "👻"
        } else if let _ = isBox(atX: x, andY: y) {
            return "📦"
        } else if let _ = isTarget(atX: x, andY: y) {
            return "🌫"
        } else {
            return "⬜️"
        }
        
    }
    
    func checkBounds (atX x: UInt8, andY y: UInt8) -> Bool {
        return x > 0 && x < room.with - 1 && y > 0 && y < room.heigth - 1
    }
    
    func addHero(hero: Hero) {
        self.hero = hero
    }
    
    func addBox(box: Box) {
        boxes.append(box)
    }
    
    func addTarget(target: Target) {
        targets.append(target)
    }
    
    func isHero(atX: UInt8, andY: UInt8) -> Bool {
        
        if let item = self.hero {
            if (item.x == atX && item.y == andY) { return true }
            
            return false
        }
        return false
    }
    
    func isBox(atX: UInt8, andY: UInt8) -> Box? {
        
        for item in boxes {
            if item.x == atX && item.y == andY { return item }
        }
        return nil
    }
    
    func isTarget(atX: UInt8, andY: UInt8) -> Target? {
        
        for item in targets {
            if item.x == atX && item.y == andY { return item }
        }
        return nil
    }
    
    enum Direction {
        case up
        case down
        case left
        case right
    }
    
    func moveHero(point: (UInt8, UInt8), at direction: Direction) {
        
        if let hero = hero {
            
            var canMove = true
            
            if let box = isBox(atX: point.0, andY: point.1) {
                if !push(box: box, at: direction) {
                    canMove = false
                }
            }
            
            if canMove {
                hero.x = point.0
                hero.y = point.1
             
            }
        }
    }
    
    func moveHero(to: Direction) {
        if let hero = hero {
            let x = hero.x
            let y = hero.y
            
            switch to {
            case .up: moveHero(point: (x, y + 1), at: .up)
            case .down: moveHero(point: (x, y - 1), at: .down)
            case .left: moveHero(point: (x - 1, y), at: .left)
            case .right: moveHero(point: (x + 1, y), at: .right)
                
            }
        }
    }
    
    func push(box: Box, at: Direction) -> Bool {
        var i = 0
        for item in boxes {
            if item === box {
                
                switch at {
                case .up:
                    
                    if checkBounds(atX: box.x, andY: box.y + 1) {
                        boxes[i].y += 1
                        return true
                    }
                    
                case .down:
                    
                    if checkBounds(atX: box.x, andY: box.y - 1) {
                        boxes[i].y -= 1
                        return true
                    }
                    
                case .left:
                    
                    if checkBounds(atX: box.x - 1, andY: box.y) {
                        boxes[i].x -= 1
                        return true
                    }
                    
                case .right:
                    
                    if checkBounds(atX: box.x + 1, andY: box.y) {
                        boxes[i].x += 1
                        return true
                    }
                    
                }
                
                return false
                
            }
            i += 1
        }
        return false
    }
    
    
    init(with: UInt8, heigth: UInt8) {
        self.with = with
        self.heigth = heigth
        self.boxes = []
    }
    
}


class Hero {
    
    var room : Room
    var x : UInt8 {
        didSet {
            x = room.checkBounds(atX: x, andY: y) ? x : oldValue
        }
    }
    
    var y : UInt8 {
        didSet {
            y = room.checkBounds(atX: x, andY: y) ? y : oldValue
        }
    }
    
    init(inRoom: Room, atX x: UInt8, andY y: UInt8) {
        self.x = x
        self.y = y
        self.room = inRoom
    }
    
}

class Box {
    
    var room : Room
    var movable = true
    var x : UInt8 {
        didSet {
            x = room.checkBounds(atX: x, andY: y) ? x : oldValue
        }
    }
    
    var y : UInt8 {
        didSet {
            y = room.checkBounds(atX: x, andY: y) ? y : oldValue
        }
    }
    
    init(inRoom: Room, atX x: UInt8, andY y: UInt8) {
        self.x = x
        self.y = y
        self.room = inRoom
    }
    
}

class Target {
    
    var room : Room
    var x : UInt8 {
        didSet {
            x = room.checkBounds(atX: x, andY: y) ? x : oldValue
        }
    }
    
    var y : UInt8 {
        didSet {
            y = room.checkBounds(atX: x, andY: y) ? y : oldValue
        }
    }
    
    init(inRoom: Room, atX x: UInt8, andY y: UInt8) {
        self.x = x
        self.y = y
        self.room = inRoom
    }
    
}



// MAIN PROGRAM

// TODO Fix bug with room size (if with != heigth - borders are invalid)
var room = Room(with: 10, heigth: 10)
var box = Box(inRoom: room, atX: 1, andY: 7)
var target = Target(inRoom: room, atX: 2, andY: 2)
var man = Hero(inRoom: room, atX: 1, andY: 6)
var box2 = Box(inRoom: room, atX: 6, andY: 6)


room.addBox(box: box)
room.addBox(box: box2)
room.addTarget(target: target)
room.addHero(hero: man)

room.moveHero(to: .up)

//room.moveHero(to: .right)
room.moveHero(to: .right)
room.moveHero(to: .right)
room.moveHero(to: .right)
room.moveHero(to: .right)
room.moveHero(to: .right)
room.moveHero(to: .down)
room.moveHero(to: .down)
room.moveHero(to: .down)
room.moveHero(to: .down)
room.moveHero(to: .down)
//room.moveHero(to: .left)
//room.moveHero(to: .left)
//room.moveHero(to: .left)
//room.moveHero(to: .left)


//2. Персонажу добавьте метод идти, который принимает энумчик лево, право, верх, вниз
//Этот метод должен передвигать персонажа. Реализуйте правило что персонаж не должен покинуть пределы комнаты. Подвигайте персонажа и покажите это графически
//



//3. Создать тип Ящик. У ящика также есть координата в комнате X и Y. Ящик также не может покидать пределы комнаты и ящик также должен быть распечатан вместе с персонажем в функции печати.
//

room.printRoom()


//4. Теперь самое интересное, персонаж может двигать ящик, если он стоит на том месте, куда персонаж хочет попасть. Главное что ни один объект не может покинуть пределы комнаты. Подвигайте ящик :)
//
//5. Добавьте точку в комнате, куда надо ящик передвинуть и двигайте :)
//
//Для суперменов: можете добавить массив ящиков и можете сделать консольное приложение

