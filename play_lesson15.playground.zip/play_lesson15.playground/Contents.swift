//1. Создать структуру “Описание файла” содержащую свойства:
//- путь к файлу
//- имя файла
//- максимальный размер файла на диске
//- путь к папке, содержащей этот файл
//- тип файла (скрытый или нет)
//- содержимое файла (можно просто симулировать контент)
//
//Главная задача - это использовать правильные свойства там, где нужно, чтобы не пришлось хранить одни и те же данные в разных местах и т.д. и т.п.
import Foundation

enum fileType {
    case hidden
    case visible
}

struct File {
    
    static var fileMaxSize = 100000
    let fileName: String
    let filePath: String
    var fileType: fileType
    
    var fileFullPath: String {
        
        get {
            return filePath + fileName
        }
        
    }
    
    lazy var fileContent: String = "dlkjfslkffffffoooooooooojslsjdlfjkjslsjdlfjkjslsjdlfjkjslsjdlfjk"
    
}

//var testFile = File(fileName: "test.txt", filePath: "\\home\\myfolder\\",
//                    fileType: .visible, )

var testFile = File(fileName: "test.tst", filePath: "/doo/b/d", fileType: .visible, fileContent: nil)


testFile.fileType = .visible
testFile.fileContent
testFile.fileContent = "fooo"
testFile.fileContent
testFile.fileFullPath

//
//2. Создайте энум, который будет представлять некую цветовую гамму. Этот энум должен быть типа Int и как raw значение должен иметь соответствующее 3 байтное представление цвета. Добавьте в этот энум 3 свойства типа: количество цветов в гамме, начальный цвет и конечный цвет.


enum Color : Int {
    case red = 0xff0000
    case green = 0x00ff00
    case blue = 0x0000ff
    
    var colorRange : Int {
        return Int(pow(Double(Color.blue.rawValue),3))
    }
    
    static let totalColors = 3
    static let firstColor = red.rawValue
    static let lastColor = blue.rawValue
    
}

var myColor = Color(rawValue: 255)
myColor?.colorRange
Color.firstColor
Color.lastColor
Color.green.rawValue


//
//3. Создайте класс человек, который будет содержать имя, фамилию, возраст, рост и вес. Добавьте несколько свойств непосредственно этому классу чтобы контролировать:
//- минимальный и максимальный возраст каждого объекта
//- минимальную и максимальную длину имени и фамилии
//- минимально возможный рост и вес
//- самое интересное, создайте свойство, которое будет содержать количество созданных объектов этого класса

let MaxStringLength = 20

class Human {
    
    static let maxAge = 150
    static let maxHeigth = 250.0
    static let maxWeigth = 500.0
    static let minHeigth = 40.0
    static let minWeigth = 3.0
    
    static var totalHumans = 0
    
    var name : String {
        
        didSet {
            name = Array(name).count <= MaxStringLength ? name : oldValue
        }
    }
    
    
    var surname : String {
        
        didSet {
            surname = Array(surname).count <= MaxStringLength ? surname : oldValue
        }
    }
    
    
    var age : Int {
        
        didSet {
            age = (age <= Human.maxAge) && age > 0 ? age : oldValue
        }
    }
    
    
    var heigth : Double {
        
        didSet {
            heigth = (heigth <= Human.maxHeigth) && heigth > Human.minHeigth
                ? heigth : oldValue
        }
    }
    
    
    var weigth : Double {
        
        didSet {
            weigth = (weigth <= Human.maxWeigth) && weigth > Human.minWeigth
                ? weigth : oldValue
        }
    }
    
    init(name: String, surname: String, age: Int, heigth: Double, weigth: Double) {
        
        self.name = name
        self.surname = surname
        self.age = age
        self.heigth = heigth
        self.weigth = weigth
        
        Human.totalHumans += 1
    }
    
    func print() -> String {
        return "\(self.name) \(self.surname): \(self.age) age, \(self.heigth) cm, \(self.weigth) kg"
    }
}


var firstPerson = Human(name: "John", surname: "Jackson", age: 30, heigth: 182.2, weigth: 89)


firstPerson.print()

firstPerson.name = "Scott"
firstPerson.surname = "Wilson"
firstPerson.age = -1
firstPerson.heigth = 250
firstPerson.weigth = 2
firstPerson.print()

Human.totalHumans

var person2 = Human(name: "John", surname: "Jackson", age: 30, heigth: 182.2, weigth: 89)
var person3 = Human(name: "John", surname: "Jackson", age: 30, heigth: 182.2, weigth: 89)
var person4 = Human(name: "John", surname: "Jackson", age: 30, heigth: 182.2, weigth: 89)
var person5 = Human(name: "John", surname: "Jackson", age: 30, heigth: 182.2, weigth: 89)

Human.totalHumans = 555
Human.totalHumans
