//1. Создать энум с шахматными фигруами (король, ферзь и т.д.). Каждая фигура должна иметь цвет белый либо черный (надеюсь намек понят), а так же букву и цифру для позиции. Создайте пару фигур с расположением на доске, так, чтобы черному королю был мат :) Поместите эти фигуры в массив фигур



enum Color: String {
    case white = "white"
    case black = "black"
}

enum PieceNames: String {
    case rook
    case pawn
    case knight
    case bishop
    case queen
    case king
}

enum Chess {
    case piece (type: PieceNames, color: Color, x: Character, y: Int)
    case chessboard (x: Character, y: Int)
    case space (x: Character, y: Int)
}

//2. Сделайте так, чтобы энумовские значения имели rawValue типа String. Каждому типу фигуры установите соответствующее английское название. Создайте функцию, которая выводит в консоль (текстово, без юникода) название фигуры, цвет и расположение. Используя эту функцию распечатайте все фигуры в массиве.


//for piece in pieces {
//    switch piece {
//    case let .piece (type, color, x, y):
//        print("The \(color) \(type) on \(x)\(y)")
//    default:
//        print ("Error was occured")
//    }
//}




//3. Используя красивые юникодовые представления шахматных фигур, выведите в консоли вашу доску. Если клетка не содержит фигуры, то используйте белую или черную клетку. Это должна быть отдельная функция, которая распечатывает доску с фигурами (принимает массив фигур и ничего не возвращает)


func getPiece (piece: Chess) -> String? {
    switch piece {
    //ладьи
    case let .piece (type, color, _, _) where type == .rook && color == .white:
        return("\u{2656}")
    case let .piece (type, color, _, _) where type == .rook && color == .black:
        return("\u{265C}")
        
    //пешки
    case let .piece (type, color, _, _) where type == .pawn && color == .white:
        return("\u{2659}")
    case let .piece (type, color, _, _) where type == .pawn && color == .black:
        return("\u{265F}")
        
    //кони
    case let .piece (type, color, _, _) where type == .knight && color == .white:
        return("\u{2658}")
    case let .piece (type, color, _, _) where type == .knight && color == .black:
        return("\u{265E}")
        
    //слоны
    case let .piece (type, color, _, _) where type == .bishop && color == .white:
        return("\u{2657}")
    case let .piece (type, color, _, _) where type == .bishop && color == .black:
        return("\u{265D}")
        
    //короли
    case let .piece (type, color, _, _) where type == .king && color == .white:
        return("\u{2654}")
    case let .piece (type, color, _, _) where type == .king && color == .black:
        return("\u{265A}")
        
    //ферзи
    case let .piece (type, color, _, _) where type == .queen && color == .white:
        return("\u{2655}")
    case let .piece (type, color, _, _) where type == .queen && color == .black:
        return("\u{265B}")
        
    default:
        return nil
    }
}

func checkPiece(pieceArr: [Chess], x: Character, y: Int) -> String? {
    var result = ""
    for pieceOfChess in pieceArr {
        switch pieceOfChess {
        case let .piece (_, _, pieceX, pieceY):
            if let pieceStr = getPiece(piece: pieceOfChess) {
                if (x == pieceX) && (y == pieceY) {
                    result = pieceStr
                }
            }
        default:
            return nil
        }
    }
    return result.count != 0 ? result : nil
}


//4. Создайте функцию, которая будет принимать шахматную фигуру и тюпл новой позиции. Эта функция должна передвигать фигуру на новую позицию, причем перемещение должно быть легальным: нельзя передвинуть фигуру за пределы поля и нельзя двигать фигуры так, как нельзя их двигать в реальных шахматах (для мегамонстров программирования). Вызовите эту функцию для нескольких фигур и распечатайте поле снова.

func createChessPad (pieces: [Chess], _ i: Character, _ j: Int) -> String {
    let alphabet = Array("abcdefghijklmnopqrstuvwxyz")
    
    if alphabet.contains(i) {
        let index = alphabet.index(of: i)!
        
        if let resultPiece = checkPiece(pieceArr: pieces, x: i, y: j) {
            return resultPiece
        } else {
            return (index % 2 == (j-1) % 2) ? "\u{2B1B}" : "\u{2B1C}"
        }
    } else {
        return "error: symbol \"\(i)\" is not present at \"\(String(alphabet))\""
    }
}

func createChessBoard(pieces: [Chess], columns: Int = 8, rows: Int = 8) {
    let alphabet = Array("abcdefghijklmnopqrstuvwxyz")
    var row = ""
    var maxColumns = 0
    
    maxColumns = columns > alphabet.count ? alphabet.count: columns
    
    for i in 1...maxColumns {
        for j in (1...rows).reversed() {
            row += createChessPad(pieces: pieces, alphabet[i-1], j)
        }
        print(row)
        row = ""
    }
}

func charToIndex (char: Character) -> Int {
    let alphabet = "abcdefghijklmnopqrstuvwxyz"
    var count = 0
    for a in alphabet {
        count += 1
        if char == a {
            break
        }
    }
    return count
}

func indexToChar (index: Int) -> Character? {
    let alphabet = "abcdefghijklmnopqrstuvwxyz"
    var count = 0
    for character in alphabet {
        count += 1
        if index == count {
            return character
        }
    }
    return nil
}

func validateMove (type: String, _ fromX: Character, _ fromY: Int, toX: Character, toY: Int) -> Bool {
    let x = charToIndex(char: fromX)
    let y = fromY
    let x1 = charToIndex(char: toX)
    let y1 = toY
    let maxX = 8
    let maxY = 8
    
    //    нельзя ходить на месте и за доску
    if ((x != x1) || (y != y1)) && (x1 >= 1) && (y1 >= 1) && (x1 <= maxX) && (y1 <= maxY) {
        switch type {
        case "rook":
            return (abs(x - x1) >= 1 && abs(y - y1) == 0) || (abs(x - x1) == 0 && abs(y - y1) >= 1)
            
        //        case "pawn":
        case "knight":
            return (abs(x - x1) == 1 && abs(y - y1) == 2) || (abs(x - x1) == 2 && abs(y - y1) == 1)
            //
            //        case "bishop":
            //            return x % x1 == y % y1
            //
            //
            
        //        case queen:
        case "king":
            return (x == x1 && abs(y - y1) == 1) || (y == y1 && abs(x - x1) == 1) || (abs(x - x1) == 1) && abs(y - y1) == 1
        default:
            return false
        }
    } else {
        return false
    }
}

func makeMove (piece: Chess, space: (Character, Int)) -> Chess {
    switch piece {
    case let .piece (type, color, x, y):
        if validateMove(type: type.rawValue, x, y, toX: space.0, toY: space.1) {
            return Chess.piece(type: type, color: color, x: space.0, y: space.1)
        }
        return piece
    default:
        return piece
    }
}

func makeMove (piece: Chess, inArr: [Chess], space: (Character, Int)) -> [Chess] {
    var count = 0
    var foundItem = -1
    var newPiece = piece
    var outArr = inArr
    for arrPiece in inArr {
        switch arrPiece {
        case let .piece (arrType, arrColor, arrX, arrY):
            switch piece {
                case let .piece (type, color, x, y):
                    if type == arrType && color == arrColor && x == arrX && y == arrY {
                        foundItem = count
                        if validateMove(type: type.rawValue, x, y, toX: space.0, toY: space.1) {
                          newPiece = Chess.piece(type: type, color: color, x: space.0, y: space.1)
                        }
                }
            default: continue
            }
            
        //            return piece
        default: continue
        }
        count += 1
    }
    outArr.remove(at: foundItem)
    outArr.append(newPiece)
    return outArr
}

//tests of bishop rook

//var bishop = Chess.piece(type: .bishop, color: .white, x: "a", y: 1)
//print(getStringPiece(piece: bishop))
//
//bishop = makeMove(piece: bishop, space: ("h", 4))
//print(getStringPiece(piece: bishop))


//Initial data setup

var piecesArr = [Chess]()
var kingWhite = Chess.piece(type: .king, color: .white, x: "b", y: 6)
var knightWhiteW = Chess.piece(type: .knight, color: .white, x: "c", y: 6)
var knightWhiteB = Chess.piece(type: .knight, color: .white, x: "e", y: 6)
var kingBlack = Chess.piece(type: .king, color: .black, x: "b", y: 8)
var rookWhite = Chess.piece(type: .rook, color: .white, x: "a", y: 8)

piecesArr.append(kingWhite)
piecesArr.append(knightWhiteW)
piecesArr.append(knightWhiteB)
piecesArr.append(kingBlack)
piecesArr.append(rookWhite)




createChessBoard(pieces: piecesArr, columns: 8, rows: 8)


rookWhite = makeMove(piece: rookWhite, space: ("a", 1))

piecesArr.append(rookWhite)

print("------")

createChessBoard(pieces: makeMove (piece: rookWhite, inArr: piecesArr, space: ("a", 8)), columns: 8, rows: 8)
