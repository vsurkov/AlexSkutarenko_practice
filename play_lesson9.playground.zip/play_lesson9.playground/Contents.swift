/*
import UIKit

let alphabet = Array("abcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()_+")
var text = ""

for _ in 0..<200 {
    let rnd = arc4random() % UInt32(alphabet.count)
    text += String(alphabet[Int(rnd)])
}


var temp = Array("B, C, D, F, G, H, J, K, L, M, N, P, Q, R, S, T, V, W, X, Y, Z".lowercased())
var strTemp = ""
for c in temp {
    if (c != ",") && (c != " "){
        strTemp += String(c)
    }
}
print(strTemp)
*/

/*
let aaa = Array("bcdfghjklmnpqrstvwxyz")


var vowel = 0
var consonant = 0
var num = 0
var symbol = 0

for c in text {
    switch c {
    case "a", "e", "i", "o", "u", "y":
        vowel += 1
    case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
        consonant += 1
    case "1", "2", "3", "4", "5", "6", "7", "8", "9", "0":
        num += 1
    default:
        symbol += 1
    }
}

print("The text: \(text) is contains \n\(vowel) vowels, \n\(consonant) consonant, \n\(num) numbers and \n\(symbol) other symbols.")
*/

/*
import UIKit
let age = Int(arc4random() % 101)

switch age {
case 0...3:     print("\(age) years is Early childhood")
case 3...6:     print("\(age) years is Preschool age")
case 7...12:    print("\(age) years is Junior school age")
case 13...17:   print("\(age) years is Teenage years")
case 18...21:   print("\(age) years is Youth period")
case 22...35:   print("\(age) years is Mature age (1 period)")
case 36...60:   print("\(age) years is Mature age (2 period)")
case 61...75:   print("\(age) years is Elderly age")
case 76...89:   print("\(age) years is Aged age")
case 90...101:  print("\(age) years is Longevity")
default:        print("\(age) age is no Human")
}
*/


var students = [("Загну", "Онотолий", "Давидович"),
                ("Иванов", "Василий", "Валентинович"),
                ("Абхибулы", "Архыз", "Аглы"),
                ("Еглы", "Омар", "Омарович"),
                ("Александров", "Иван", "Дмитриевич"),
                ("Сидоров", "Иван", "Иванович")]


for student in students {
    switch student {
    case let (_, name, _) where name.hasPrefix("А") || name.hasPrefix("О"):
        print("\(name) is here")
        
    case let (_, name, lastname) where lastname.hasPrefix("В") || lastname.hasPrefix("Д"):
        print("\(name) \(lastname) is here")
        
    case let (surname, _, _) where surname.hasPrefix("Е") || surname.hasPrefix("З"):
        print("\(surname) is here")
        
    default:
        print("\(student.0) \(student.1) \(student.2) дорогой ты наш человек")
    }
}

/*
let ships = [[("a",3)], [("b",3), ("b",4)]]
let shoot = ("a",3)
var resultOfShoot = ""

shooting: for ship in ships {
    for deck in ship {
        switch shoot {
        case (deck.0, deck.1): resultOfShoot = ship.capacity == 1 ? "killed" : "wounded"
        default: resultOfShoot = "missed"
        }
    }
}
print(resultOfShoot)
 */


/*
var shoot = (3,4)

var ship1 = (3,3)
switch shoot {
case (ship1.0, ship1.1): print("killed")
case (ship1.0, _): print("wounded")
case (_, ship1.1): print("wounded")
    
default:
    print("missed")
}
 */









