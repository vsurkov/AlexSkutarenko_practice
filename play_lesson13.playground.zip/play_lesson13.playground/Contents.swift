//1. Создайте структуру студент. Добавьте свойства: имя, фамилия, год рождения, средний бал.
//Создайте несколько экземпляров этой структуры и заполните их данными. Положите их всех в массив (журнал).
//


struct Student {
    var name: String
    var mName: String
    var surname: String
    var birthYear: Int
    var averageRating: Float
}

var studentsList = [Student]()
var student0 = Student(name: "Vlad", mName: "Ilich", surname: "Lenin", birthYear: 1870, averageRating: 4.4)
var student1 = Student(name: "Aohn", mName: "Ilich", surname: "Lenin", birthYear: 1870, averageRating: 4.4)
var student2 = Student(name: "John", mName: "Winston", surname: "Lenin", birthYear: 1947, averageRating: 4.9)
var student3 = Student(name: "David", mName: "Robert", surname: "Abe", birthYear: 1947, averageRating: 4.0)
var student4 = Student(name: "John", mName: "Winston", surname: "Zeiss", birthYear: 1948, averageRating: 4.8)


studentsList.append(student0)
studentsList.append(student1)
studentsList.append(student2)
studentsList.append(student3)
studentsList.append(student4)



//2. Напишите функцию, которая принимает массив студентов и выводит в консоль данные каждого.
//Перед выводом каждого студента добавляйте порядковый номер в “журнале”, начиная с 1.
//

func print(students: [Student]){
    for (x, stud) in students.enumerated() {
        
        let number = x + 1
        let name = stud.name
        let mName = stud.mName
        let surname = stud.surname
        let birthYear = stud.birthYear
        let averageRating = stud.averageRating
        
        print("\(number): \(name) \(mName) \(surname) \(birthYear)'s of birth, has \(averageRating) average rating")
    }
}

print(students: studentsList)

//
//let sorted = textArr.sorted {(a,b) -> Bool in
//    switch (priority(a), priority(b)){
//    case let (a, b) where a < b: return true
//    case let (a, b) where a > b: return false
//    default: return a < b
//    }
//}


//3. С помощью функции sorted отсортируйте массив по среднему баллу, по убыванию и распечатайте “журнал”.

print()
print("---------- sorted by descendingly -----------")
print()
print(students: studentsList.sorted(by: {$0.averageRating > $1.averageRating}))


//
//4. Отсортируйте теперь массив по фамилии (по возрастанию), причем если фамилии одинаковые,
//а вы сделайте так чтобы такое произошло, то сравниваются по имени. Распечатайте “журнал”.
//

func sortStudents(_ f: Student, _ s: Student) -> Bool {
    
    return f.surname < s.surname ? true : (f.surname == s.surname) && (f.name < s.name) ? true: false
}

print()
print("---------- sorted by surname -----------")
print()
var sortedStudents = studentsList.sorted{sortStudents($0, $1)}
print(students: sortedStudents)


//5. Создайте переменную и присвойте ей ваш существующий массив. Измените в нем данные всех студентов.
//Изменится ли первый массив? Распечатайте оба массива.

print()
print("---------- sorted, copied and changed -----------")
print()

var studentsListCopy = sortedStudents

sortedStudents[0].name = "Vladimir"
sortedStudents[0].mName = "Ilichev"
sortedStudents[0].surname = "Leninsky"
sortedStudents[0].birthYear = 1900
sortedStudents[0].averageRating = 2.3

sortedStudents[1].name = "Vladimir"
sortedStudents[1].mName = "Ilichev"
sortedStudents[1].surname = "Leninsky"
sortedStudents[1].birthYear = 1900
sortedStudents[1].averageRating = 2.3

sortedStudents[2].name = "Vladimir"
sortedStudents[2].mName = "Ilichev"
sortedStudents[2].surname = "Leninsky"
sortedStudents[2].birthYear = 1900
sortedStudents[2].averageRating = 2.3

sortedStudents[3].name = "Vladimir"
sortedStudents[3].mName = "Ilichev"
sortedStudents[3].surname = "Leninsky"
sortedStudents[3].birthYear = 1900
sortedStudents[3].averageRating = 2.3

sortedStudents[4].name = "Vladimir"
sortedStudents[4].mName = "Ilichev"
sortedStudents[4].surname = "Leninsky"
sortedStudents[4].birthYear = 1900
sortedStudents[4].averageRating = 2.3

//print("Copy of studentsList")
//print(students: studentsListCopy)
//print("Modyfied studentsList")
//print(students: sortedStudents)


//
//6. Теперь проделайте все тоже самое, но не для структуры Студент, а для класса.
//Какой результат в 5м задании? Что изменилось и почему?
//

class CStudent {
    var name: String
    var mName: String
    var surname: String
    var birthYear: Int
    var averageRating: Float
    
    init(name: String, mName: String, surname: String, birthYear: Int, averageRating: Float) {
        self.name = name
        self.mName = mName
        self.surname = surname
        self.birthYear = birthYear
        self.averageRating = averageRating
    }
}

var studentsListC = [CStudent]()
var stud0 = CStudent(name: "Vlad", mName: "Ilich", surname: "Lenin", birthYear: 1970, averageRating: 2.2)
var stud1 = CStudent(name: "Aohn", mName: "Ilich", surname: "Lenin", birthYear: 1870, averageRating: 4.4)
var stud2 = CStudent(name: "John", mName: "Winston", surname: "Lenin", birthYear: 1947, averageRating: 4.9)
var stud3 = CStudent(name: "Hugues", mName: "Aubriot", surname: "Abe", birthYear: 1947, averageRating: 4.0)
var stud4 = CStudent(name: "John", mName: "Winston", surname: "Zeiss", birthYear: 1948, averageRating: 4.8)


studentsListC.append(stud0)
studentsListC.append(stud1)
studentsListC.append(stud2)
studentsListC.append(stud3)
studentsListC.append(stud4)

func print(students: [CStudent]){
    for (x, stud) in students.enumerated() {
        
        let number = x + 1
        let name = stud.name
        let mName = stud.mName
        let surname = stud.surname
        let birthYear = stud.birthYear
        let averageRating = stud.averageRating
        
        print("\(number): \(name) \(mName) \(surname) \(birthYear)'s of birth, has \(averageRating) average rating")
    }
}

print()
print("---------- array of Students (Class) -----------")
print(students: studentsListC)


//3. С помощью функции sorted отсортируйте массив по среднему баллу, по убыванию и распечатайте “журнал”.

print()
print("---------- array of Class sorted by descendingly -----------")
print()
//print(students: studentsListC.sorted(by: {$0.averageRating > $1.averageRating}))
//
//print()
//print("---------- sorted by surname -----------")
//print()


var sortedStudentsC = studentsListC.sorted{(f,s) in
    f.surname < s.surname ? true : (f.surname == s.surname) && (f.name < s.name) ? true: false
}
var copyOfSortedStudentsC = sortedStudentsC
copyOfSortedStudentsC[0].name = "Vasiliy"
copyOfSortedStudentsC[0].mName = "Jason"
copyOfSortedStudentsC[0].surname = "Garryson"
copyOfSortedStudentsC[0].birthYear = 1999
copyOfSortedStudentsC[0].averageRating = 9.99

copyOfSortedStudentsC[1].name = "Vasiliy"
copyOfSortedStudentsC[1].mName = "Jason"
copyOfSortedStudentsC[1].surname = "Garryson"
copyOfSortedStudentsC[1].birthYear = 1999
copyOfSortedStudentsC[1].averageRating = 9.99

copyOfSortedStudentsC[2].name = "Vasiliy"
copyOfSortedStudentsC[2].mName = "Jason"
copyOfSortedStudentsC[2].surname = "Garryson"
copyOfSortedStudentsC[2].birthYear = 1999
copyOfSortedStudentsC[2].averageRating = 9.99

copyOfSortedStudentsC[3].name = "Vasiliy"
copyOfSortedStudentsC[3].mName = "Jason"
copyOfSortedStudentsC[3].surname = "Garryson"
copyOfSortedStudentsC[3].birthYear = 1999
copyOfSortedStudentsC[3].averageRating = 9.99

copyOfSortedStudentsC[4].name = "Vasiliy"
copyOfSortedStudentsC[4].mName = "Jason"
copyOfSortedStudentsC[4].surname = "Garryson"
copyOfSortedStudentsC[4].birthYear = 1999
copyOfSortedStudentsC[4].averageRating = 9.99


print()
print("---------- initial sorted arr of OStudent -----------")
print()
print(students: studentsListC)
print("---------- edited sorted arr of OStudent -----------")
print()
print(students: studentsListC)

//007. Уровень супермен
//
//Выполните задание шахмат из урока по энумам используя структуры либо классы

