// 1

/*
var groupDict = ["JayJonson":2, "JimGarner": 5, "TimMitchel": 4, "AndreaTerua": 3]

groupDict["JayJonson"] = 4
print("Assesment has been changed to = \(groupDict.updateValue(5, forKey: "AndreaTerua")!)")

groupDict["BobDilan"] = 3
groupDict["LisaSmith"] = 4

groupDict.removeValue(forKey: "JayJonson")
groupDict["TimMitchel"] = nil

print(groupDict)
var summ = 0
for i in groupDict.values {
    summ += i
}
print("Total: \(summ), and average assisment: \(summ / groupDict.count)")
*/


// 2
/*
let monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Now", "Dec"]
let monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
var dictOfMonth = [String:Int]()

for (i, a) in monthNames.enumerated() {
    dictOfMonth[a] = monthDays[i]
}

for (name, days) in dictOfMonth {
    print(name, days)
}

for month in dictOfMonth {
    print(month.key, month.value)
}
*/

//3


let checkerboardDimensions =  9
var pads = [String:Bool]()
let alphabet = Array("abcdefghijklmnopqrstuvwxyz")
var chessPads = [[String]]()

/*
for _ in 0...8 {
    var arr = [Int]()
    
    for j in 0...8 {
        arr.append(j)
    }
    chessPads.append(arr)
}
print(chessPads)
*/









for j in 1...checkerboardDimensions {
    var arr = [String]()
    
    for i in 1...checkerboardDimensions {
        let padName = "\(alphabet[j-1])" + String(i)
        let isWhite = (j % 2 == (i-1) % 2)
        
        pads[padName] = isWhite
        arr.append(isWhite ? "\u{2B1B}" : "\u{2B1C}")
            
    }
    chessPads.append(arr)
}

//print(pads)

if !pads["a1"]! && pads["a4"]! && !pads["a7"]! && pads["a8"]!
    && pads["b1"]! && !pads["b4"]! && pads["b5"]! && !pads["b8"]!
    && pads["c2"]! && !pads["c3"]! && pads["c4"]! && pads["c8"]!
    && pads["h1"]! && pads["h5"]! && !pads["h6"]! && !pads["h8"]!{
    print("Test passed \u{265E} \u{2658}")
} else {
    print("Test failed")
}

//print(chessPads)


for i in 0..<checkerboardDimensions {
    print(chessPads[i].joined())
    
}



