//1. Самостоятельно повторить проделанное в уроке
//
import Foundation

struct Student {
    static let currentYear = 2018
    var name : String {
        willSet {
            //            print("We will set \(newName) on instead of \(name)")
        }
        didSet {
            //            print("We just now set \(name) on instead of \(oldName)")
            name = name.capitalized
        }
    }
    
    var surname : String {
        didSet {
            surname = surname.capitalized
        }
    }
    
    var fullname : String {
        get {
            return name + " " + surname
        }
        set {
            let words = newValue.components(separatedBy: " ")
            if words.count > 0 {
                name = words[0]
            }
            if words.count > 1 {
                surname = words[1]
            }
            if words.count > 2 {
                surname = words[1] + " " + words[0]
            }
        }
    }
    
    var birthDate: Date
    var age: Int {
        return Student.currentYear - birthDate.year
    }
    
    var yearsOfStudy: Int {
        return age > 6 ? age - 6: 0
    }
}

struct Date {
    var year: Int
    var month: Int
    var day: Int
}


var stud1 = Student(name: "Vasili", surname: "Pupkin", birthDate: Date(year: 1983, month: 04, day: 22))
//stud1.name
//stud1.surname
//stud1.fullname
//
//stud1.name = "geNNADy"
//stud1.name
//stud1.fullname
stud1.fullname = "John Mitchel Doe"
stud1.name
stud1.surname
stud1.fullname



//2. Добавить студенту property «Дата рождения» (пусть это будет еще одна структура, содержащая день, месяц, год) и
//два computed property: первое — вычисляющее его возраст, второе — вычисляющее, сколько лет он учился (считать, что он
//учился в школе с 6 лет, если студенту меньше 6 лет — возвращать 0)
//

stud1.age
stud1.birthDate.year
stud1.yearsOfStudy


//3. Создать структуру «Отрезок», содержащую две внутренние структуры «Точки». Структуру «Точка» создать самостоятельно,
//несмотря на уже имеющуюся в Swift’е. Таким образом, структура «Отрезок» содержит две структуры «Точки» — точки A и B
//(stored properties). Добавить два computed properties: « середина отрезка» и «длина» (считать математическими функциями)
//

struct Segment {
    
    var a: Point
    var b: Point
    var middle: Point {
        set {
            let shiftX = newValue.x - middle.x
            let shiftY = newValue.y - middle.y
            
            a.x += shiftX
            a.y += shiftY
            b.x += shiftX
            b.y += shiftY
        }
        get {
            let newX = (a.x + b.x) / 2
            let newY = (a.y + b.y) / 2
            return Point(x: newX, y: newY)
        }
    }
    
    var length: Double {
        get {
            return sqrt(pow((b.x-a.x),2) + pow((b.y-a.y),2))
        }
        set {
            b.x = a.x + newValue * (b.x-a.x) / length
            b.y = a.y + newValue * (b.y-a.y) / length
        }
    }
}
struct Point {
    
    var x: Double
    var y: Double
}

var mySegment = Segment(a: Point(x: 1, y: 1), b: Point(x: 4, y: 1))
mySegment.middle.x
mySegment.middle.y
mySegment.length
mySegment.length = 4
mySegment.length
mySegment.middle.x
mySegment.middle.y
mySegment.b.x
mySegment.b.y



//4. При изменении середины отрезка должно меняться положение точек A и B. При изменении длины, меняется положение точки B

mySegment.middle = Point(x: 10, y: 5)
mySegment.middle.x
mySegment.middle.y
mySegment.a.x
mySegment.a.y
mySegment.b.x
mySegment.b.y
mySegment.length


