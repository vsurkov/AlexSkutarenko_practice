// 1. Comput a seconds between date of birth and current date

let birthDay = (day: 22, month: 4, year: 1983)
let currentDay = (day: 15, month: 3, year: 2018)
var totalDays = 0

let calDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
let calNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Now", "Dec"]

for (i, _) in calNames.enumerated() {
    print("\(calNames[i]) : \(calDays[i]) ")
}



/*
 
 var cal = [(mon: "jan", days: 31) , (mon: "feb", days: 28), (mon: "mar", days: 31)]
 cal += [(mon: "apr", days: 30) , (mon: "may", days: 31), (mon: "jun", days: 30)]
 cal += [(mon: "jul", days: 31) , (mon: "aug", days: 31), (mon: "sep", days: 30)]
 cal += [(mon: "oct", days: 31) , (mon: "nov", days: 30), (mon: "dec", days: 31)]

 
for cd in cal {
    print("\(cd.mon): \(cd.days)")
}

var i = 0
var di = cal.count - 1


for cd in cal {
    print("\(cd.mon): \(cal[di].days)")
    di -= 1
}


var i = 0
var sum = 0
for cd in cal {
    if i < (birthDay.month - 1) {
        sum += cd.days
        i += 1
    }
}

i = 0
for cd in cal {
    if i < (currentDay.month - 1)  {
        sum += cd.days
        i += 1
    }
}

print(sum)
totalDays = sum + birthDay.day + currentDay.day + ((currentDay.year - birthDay.year) * 365) * 24 * 3600

*/
var arr = [1, nil, 20]
var sum = 0

/*
for i in arr {
    if i != nil {
        sum += i!
    }
}
*/
 for i in arr {
    if let i = i {
        sum += i
    }
 }
/*
for i in arr {
    sum += i ?? 0
}
sum

 */

let alphabet = "abcdefghijklmnopqrstuvwxyz"
var anotherAlph = [String]()

for char in alphabet {
    anotherAlph.insert(String(char), at: 0)
}
print(anotherAlph)





















