
//version 1
/*
func createChessPad (_ i: Character, _ j: Int) -> String {
    let alphabet = Array("abcdefghijklmnopqrstuvwxyz")
    
    if alphabet.contains(i) {
        let index = alphabet.index(of: i)!
        return (index % 2 == (j-1) % 2) ? "\u{2B1B}" : "\u{2B1C}"
    } else {
        return "error: symbol \"\(i)\" is not present at \"\(String(alphabet))\""
    }
}


func createChessBoard(columns: Int = 8, rows: Int = 8) {
    let alphabet = Array("abcdefghijklmnopqrstuvwxyz")
    var row = ""
    var maxColumns = 0
    
    maxColumns = columns > alphabet.count ? alphabet.count: columns
    
    for i in (1...maxColumns).reversed() {
        for j in 1...rows {
            row += createChessPad(alphabet[i-1], j)
        }
        print(row)
        row = ""
    }
}

createChessBoard(columns: 6, rows: 6)
*/


func createChessPad (_ i: Character, _ j: Int) -> String {
    let alphabet = Array("abcdefghijklmnopqrstuvwxyz")
    
    if alphabet.contains(i) {
        let index = alphabet.index(of: i)!
        return (index % 2 == (j-1) % 2) ? "\u{2B1B}" : "\u{2B1C}"
    } else {
        return "error: symbol \"\(i)\" is not present at \"\(String(alphabet))\""
    }
}


func createChessBoard(columns: Int = 8, rows: Int = 8) {
    let alphabet = Array("abcdefghijklmnopqrstuvwxyz")
    var row = ""
    var maxColumns = 0
    
    maxColumns = columns > alphabet.count ? alphabet.count: columns
    
    for i in (1...maxColumns).reversed() {
        for j in 1...rows {
            row += createChessPad(alphabet[i-1], j)
        }
        print(row)
        row = ""
    }
}

createChessBoard(columns: 6, rows: 6)


