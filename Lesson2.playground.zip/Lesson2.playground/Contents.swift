print("The Int has: min  = \(Int.min); max =\(Int.max) value")
print("The Int8 has: min  = \(Int8.min); max =\(Int8.max) value")
print("The Int16 has: min  = \(Int16.min); max =\(Int16.max) value")
print("The Int32 has: min  = \(Int32.min); max =\(Int32.max) value")
print("The Int64 has: min  = \(Int64.min); max =\(Int64.max) value")

print("The UInt has: min  = \(UInt.min); max =\(UInt.max) value")
print("The UInt8 has: min  = \(UInt8.min); max =\(UInt8.max) value")
print("The UInt16 has: min  = \(UInt16.min); max =\(UInt16.max) value")
print("The UInt32 has: min  = \(UInt32.min); max =\(UInt32.max) value")
print("The UInt64 has: min  = \(UInt64.min); max =\(UInt64.max) value")

let intA = 3
let floatB : Float = 3.3
let doubleC = 4.9

var sumInt = Int(Double(intA) + Double(floatB) + doubleC)
var sumFloat = Float(intA) + floatB + Float(doubleC)
var sumDouble = Double(intA) + Double(floatB) + doubleC

if Double(sumInt) > sumDouble {
    print("summ in integer are better")
} else {
    print("summ in double are better")
}
